*********************************************************************
** Multi Scripter ver 1.0 // compiled 12/28/00
** created by Slayde
** email  damiller@iqmail.net
*********************************************************************

**Multi Scripter Instructions**

** Reminder **
To all you GM's and Admins who want to use this.
If you use custom multi.idx and multi.mul files for your server. You players
will need to download a copy of them and use them in order to see the new
buildings. This shouldn't be a problem, because these 2
files are really small zipped up. :-)

Good luck and email me with any comments, suggestions, or questions you have.

About this program:
This program allows GM's to add their own custom building designs into the UO client multi.idx
and multi.mul files.  These buildings will be just like OSI's player owned buildings that can be 
built with deeds.  They are also static, so they wont cause much lag. :-)

*** This requires the Sphere UO emu for this program *******

INSTRUCTIONS
step 1 - backup the multi.mul and multi.idx files in your UO folder
	 ( also the ones in your servers mul files
	 folder if you use a separate one for the server).

step 2 - Enter the path and filename to the multi.idx and multi.mul files or browse to them.

step 3 - Load Sphere with an empty worldfile (just to be safe) and go to green acres. 
	 Build any type of multi structure that you want to patch to the UO client mul files.

step 4 - **Exporting your multi using SPHERE 51a**

	 (Time to export it) If you built your buiding using Sphere 51a or older, Go to the
	 middle of your building and type the command .export mymulti.wsc 1 100 to export those 
	 items to a file named mymulti.wsc in the sphere server folder.. NOTE you can change mymulti
	 to whatever name you would like. This command tells sphere to export all items
	 within 100 spaces of you, to uox3.wsc file format. The 1 before the 100
	 range, tells it to only export items, no spawners or npcs. It is very 
	 IMPORTANT that you include the .wsc on the end of the filename when 
	 exporting the multi or the file will not be the correct format.

	 **Exporting your Multi using SPHERE 54t test version (This method does not work prior to 54t)**
	 Go to your multi and from the outside, do .extract mymulti.txt 1. The 1 after it is 
	 important! Then target around your multi like you would if you were using the .nuke
	 command.  Sphere should say that is extracted items to this file. *WARNING* Older 
	 versions of sphere will only extract static items that are a part of uo map or were
	 worldforged. I have tested 54t and it will also extract dynamic item as well, so if 
	 you create your building in green acres, it will extract only the items for your multi,
	 so that is the best place to build multis for extraction.

step 5 - Run the Multi Scripter.exe program and click the load button.  Browse to
	 and select the file that you created with the .export command in Sphere.

step 6 - Fill in the script info text boxes with what you want to name this building,
	 the buyvalue price and sellvalue price. Once all three text boxes are filled
	 in, the create scripts button will be enabled.  ** Note if you choose the sphere 54+ script
	 version, the buyvalue will be added to the scripts as the VALUE= line since the new scripts
	 do not use the buyvalue and sellvalue lines anymore.

step 7 - Now press patch to patch your multi to the multi mul files. You need to do 

step 8 - Choose the sphere scripts format you want to create.  Options are the server 51a
	 or the new 54+ script format.

step 9 - Now press the create scripts button, if you already filled in the script text boxes,
	 and a window pops up with the multi script and the deed script that goes to it.
	 Copy and paste these to your sphere script files. **51a scripts will need to be
	 placed in numerical order within your scripts**
	 Any items that you put their ID into the components.txt file will be added to
	 the multi script as components and will not be patched to the mul files. These
	 are items like doors, forges, etc that need to be usuable for the players and
	 not static. I already added doors and some house signs, forges and a few other
	 items to the components.txt file. Feel free to add any others you need to be
	 made components.

Step 11   Copy the scripts from into your sphereitem script files. 
	  Do not modify the Multi ID #. **51a scripts Just change the Deed ID to fit your scripts**

Step 12   Backup your original multi.idx & multi.mul files and copy the modified ones to
	  your uo folder and to the folder that holds the mul files for your server if
	  you keep those in a separate location than your uo install folder.

step 10 - Test it out.  Load sphere and create the deed to your new building.  Click
	  the deed and you now have a new custom building for your players to buy. :-)

Any problems, suggestions, feedback, or questions, feel free to email me 
at damiller@iqmail.net

Enjoy!

Slayde