#ifndef __GUMP_H__
#define __GUMP_H__

struct GumpInfo
{
	string name;
	long int value;
	UI08 type;
	string stringValue;
	// acceptable type values
	// 0 -> straight plain long int
	// 1 -> hex long int
	// 2 -> long int separated into 4 parts, decimal
	// 3 -> long int separated into 4 parts, hex
	// 4 -> string
	// 5 -> 2 byte hex display
	// 6 -> 2 byte decimal display
};

class GumpDisplay
{
private:
	vector< GumpInfo * > gumpData;
	UI16 width, height;	// gump width / height
	cSocket *toSendTo;
	stringList one, two;
	string title;
public:
	void AddData( GumpInfo *toAdd );
	void AddData( const char *toAdd, long int value, UI08 type = 0 );
	void AddData( const char *toAdd, const char *toSet, UI08 type = 4 );
	GumpDisplay( cSocket *target );
	GumpDisplay( cSocket *target, UI16 gumpWidth, UI16 gumpHeight );
	virtual ~GumpDisplay();
	void SetTitle( const char *newTitle );
	void Send( long gumpNum, bool isMenu, SERIAL serial );
	void Delete( void );
};

class cGump
{
public:
	void Button( cSocket *s, SI32 button, UI08 tser1, UI08 tser2, UI08 tser3, UI08 tser4, SI32 type );
	void Input( cSocket *s );
	void Menu( cSocket *s, int m );
	void Open( cSocket *s, CChar *i, UI16 gumpNum );
};

#endif

