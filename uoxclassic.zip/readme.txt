2001.7.2
This directory contains the current source code of UOX3 0.95.01 as it currently is implemented.
2001.6.6
This directory contains the sourcecode of "UOX3 1.0" and all documentation.
Yeshe