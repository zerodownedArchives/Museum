// cAccounts.cpp: implementation of the cAccount class.
//
//////////////////////////////////////////////////////////////////////

//#include "cAccount.h"
#include "uox3.h"
#include <fstream>
//#include <string>

using namespace std;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

//	Extentions: (.adm)-text accounts file  (.abs)-binary accounts file

cAccounts::cAccounts() : AccountCount( 0 ), highestAccountNumber( -1 ), isReloaded( false ), isBinary( false ), isValid( false )
{
	PathToFile.erase();
	isReloaded = isBinary = isValid = false;
}

cAccounts::cAccounts( const char *accountsfile ) : AccountCount( 0 ), highestAccountNumber( -1 ), isReloaded( false ), isBinary( false ), isValid( false )
{
	PathToFile = accountsfile;
	isBinary = FileType();
}

cAccounts::~cAccounts()
{

}

//o--------------------------------------------------------------------------
//|	Function		-	bool ConvertAccounts(const char *filename)
//|	Date			-	March 8, 2000
//|	Programmer		-	EviLDeD
//|	Modified		-
//o--------------------------------------------------------------------------
//|	Purpose			-	This function is does basically what the name implies
//|						It reads in a accounts format, converts that format into
//|						the format for use with the server. At this stage this
//|						function will convert only between text versions 1.0
//|						and the new 2.0 Script/Accounts/Item format
//o--------------------------------------------------------------------------
bool cAccounts::ConvertAccounts( const char *filename )
{
	ifstream ifsSource;
	ifstream ifsDestination;
	char szInBuffer[128], szOutBuffer[1024];
	memset( szOutBuffer, 0x00, 1024 );
	ifsSource.open( "./accounts.adm", ios::in );
	if(!ifsSource.is_open())
	{
		ErrNum = 0x00000100;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Unable to open the specified file for input";
		return false;
	}
	ifsDestination.open(filename,ios::out);
	if(!ifsDestination.is_open())
	{
		ErrNum = 0x00000200;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Unable to open the specified file for output";
		return false;
	}
	
	while(!ifsSource.eof())
	{
		ifsSource.getline(szInBuffer,127);
		if(szInBuffer==NULL)	continue;

	}
	ifsSource.getline(szInBuffer,127);
	//if(szLine==NULL)
	//{	//	Assume that this accounts file is version 1
	//	ErrNum = 0x00000001;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
	//	ErrDesc = "Unable to determine version of Accounts file";
	//	return "1.0";
	//}	
	// Im going to assume that old UOX still has accounts.adm in the rood dir.


	return false;
}

//o--------------------------------------------------------------------------
//|	Function		-	const char *CheckAccountsVersion(const char *filename)
//|	Date				-	March 8, 2000
//|	Programmer	-	EviLDeD
//|	Modified		-
//o--------------------------------------------------------------------------
//|	Purpose			-	This function attempts to open and read in the first line
//|								of the accounts.adm file to determine the version that the
//|								file is in. This is primarily intended to differentiate 
//|								between account files to determine format
//o--------------------------------------------------------------------------
const char *cAccounts::CheckAccountsVersion( const char *filename )
{
	ifstream isFile;
	char szLine[128];

	memset( szLine, 0x00, 128 );
	if( filename == NULL )
		isFile.open( "./accounts.adm", ios::in );
	else
		isFile.open(filename,ios::in);
	if(!isFile.is_open())
	{
		ErrNum = 0x00000100;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Unable to open the specified file";
		return "1.0";
	}
	isFile.getline( szLine, 127 );
	if( szLine == NULL )
	{	//	Assume that this accounts file is version 1
		ErrNum = 0x00000001;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Unable to determine version of Accounts file";
		return "1.0";
	}

	char *p; //,strUOXVersion[15],strBuildNumber[8];
	if((p=strtok(szLine,"-"))==NULL)
	{
		ErrNum = 0x00000001;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Unable to determine version of Accounts file";
		return "1.0";
	}
	if( strncmp( p, "AV", ( 2 * sizeof( char ) ) ) )
	{
		ErrNum = 0x00000002;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Expected token[AV] was not found.";
		return "1.0";
	}
	strcpy(szAccountsVersion,(szLine+2));
	isFile.close();
	return szAccountsVersion;
}

UI32 cAccounts::ReadToken( FILE *openfile )
{
	return 0;
}

long cAccounts::LoadAccounts( void )
{
	return -1L;
}

long cAccounts::LoadAccounts( int mode )
{	// Mode: (0) - text (1) - Binary (2) - xor'd binary
	switch( mode )
	{
	case 1:
		break;
	case 0:
	default:
		ifstream ifsFile;
		char szLine[128];
		int	case_select=0;
		highestAccountNumber = 0;

		if( PathToFile.empty() )
		{
			ErrNum = 0x00000001;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
			ErrDesc = "Path to accounts file is invalid, or empty";
			return -1;
		}
		if( stricmp( CheckAccountsVersion( PathToFile.c_str() ), "1.0" ) == 0 )
		{	//	Deal with the default version of this file
			case_select = 0;
		}
		else
		{	//	Put the binary, and other modes of account file processing here.
			case_select = 1;
		}
		bool braces[3] = { false, false, false };
		long actidx = -1;	// when we enter our first area, it will become 0
		switch( case_select )
		{
			case 1:
				return 0l;
			case 0:
			default:
				ifsFile.open( PathToFile.c_str(), ios::in );
				if( !ifsFile.is_open() )
				{
					ErrNum = 0x00000100;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
					ErrDesc = "Unable to open the specified file";
					return -1;
				}
				ifsFile.getline( szLine, 127 );
				ACTREC *actPointer = NULL;
				while( !ifsFile.eof() )
				{
					if( szLine[0] == '/' )
					{
						ifsFile.getline( szLine, 127 );
						continue;
					}
					if( !strnicmp( szLine, "SECTION ACCOUNT", strlen( "SECTION ACCOUNT" ) ) )
					{
						actPointer = new ACTREC;	// only create a new account when we enter a new area
						memset( actPointer, 0x00, sizeof( ACTREC ) );
						actPointer->inworld = INVALIDSERIAL;
						actPointer->characters.resize( 5 );
						if( strlen( szLine ) != strlen( "SECTION ACCOUNT" ) )
							actPointer->id = actidx = makeNum( &szLine[strlen( "SECTION ACCOUNT" )] );
						else	// this was commented out, are you sure we want this Evil? If so, we are just incrementing what we read by 1
							actidx = -1;//actPointer->id = nextAccutNum;// actidx = -1;
						//nextAccutNum = max(nextAccutNum, actidx+1);

						if( actidx >= highestAccountNumber )
							highestAccountNumber = actidx+1;

						braces[0] = true;
						ifsFile.getline( szLine, 127 );
						continue;	// get next line
					}
					if( braces[0] && szLine[0] == '{' ) 
					{
						if( !braces[1] )
						{
							braces[1] = true;
							ifsFile.getline( szLine, 127 );
							continue;
						}
						else
						{
							ifsFile.close();
							ErrNum = 0x00000001;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
							ErrDesc = "Another '{' was encountered before '}'";
							return -1;
						}
					}
					if( braces[0] && braces[1] && szLine[0] == '}' )
					{
						braces[0] = braces[1] = false;
						actPointer->id = actidx;
						string keystring( actPointer->username );
						ACTREC *alreadyExists = GetAccount( actPointer->username );
						if( alreadyExists != NULL )
						{
							actPointer->charactercount = alreadyExists->charactercount;
							actPointer->characters[0] = alreadyExists->characters[0];
							actPointer->characters[1] = alreadyExists->characters[1];
							actPointer->characters[2] = alreadyExists->characters[2];
							actPointer->characters[3] = alreadyExists->characters[3];
							actPointer->characters[4] = alreadyExists->characters[4];
							delete alreadyExists;
						}
						actMap[keystring] = actPointer;
						ifsFile.getline( szLine, 127 );
						continue;
					}
					if( !braces[0] && ( braces[1] || braces[2] ) )
					{
						ifsFile.close();
						ErrNum = 0x00000001;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
						ErrDesc = "Invalid block encountered";
						return -1;
					}
					char *token[2] = { NULL, NULL };
					token[0] = strtok( szLine, " " );	token[1] = strtok( NULL, "\n" );
					if( token[1] == NULL )	// no data!
					{
						ifsFile.getline( szLine, 127 );
						continue;
					}
					if( braces[0] && braces[1] )
					{
						if( !stricmp( token[0], "NAME" ) )
							strcpy( actPointer->username, token[1] );
						else if( !stricmp( token[0], "PASS" ) )
							strcpy( actPointer->password, token[1] );
						else if( !stricmp( token[0], "BAN" ) )
						{
							actPointer->isbanned = (makeNum( token[1] ) > 0);
						}
						else if( !stricmp( token[0], "TIMEBAN" ) )
						{	//	This will be downgraded, and removed
							actPointer->ban_duration = atol( token[1] );
						}
						else if( !stricmp( token[0], "LASTIP" ) )
						{
							actPointer->ipaddress[0] = inet_addr( (const char*)token[1] );
						}
						else if( !stricmp( token[0], "PUBLIC" ) )
						{
							actPointer->ispublic = ( !stricmp( token[1], "ON" ) || !stricmp( token[1], "YES" ) );
						}
						else if( !stricmp( token[0], "CONTACT" ) )
						{
							strcpy( actPointer->comment, token[1] );
						}
						else if( !stricmp( token[0], "ID" ) )
						{
							if( ( actPointer->id = atol( token[1] ) ) == 0L )
								actPointer->id = -1;
						}
						else if( !stricmp( token[0], "PATH" ) )
						{
							strcpy( actPointer->path, token[1] );
						}
						else if( !stricmp( token[0], "BANDURATION" ) )
						{	// This is the new conversion from TIMEBAN
							actPointer->ban_duration = atol( token[1] );
						}
						else if( !stricmp( token[0], "XGMCLIENT" ) )
						{
							actPointer->isxgm = ( !stricmp( token[1], "ON" ) || !stricmp( token[1], "YES" ) );
						}
						ifsFile.getline( szLine, 127 );
					}
				}
				break;
		}
	}
	AccountCount = actMap.size();
	PostLoadProcessing();
	return 0;
}

bool cAccounts::FileType( void )
{
	ifstream ifsFile;
	UI08 szLine[10];

	if( PathToFile.empty() )
		return false;

	ifsFile.open( PathToFile.c_str(), ios::in|ios::binary );
	if( !ifsFile.is_open() )
	{
		ErrNum = 0x00000100;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
		ErrDesc = "Unable to open the specified file";
		return false;
	}
	ifsFile.get( (char *)szLine, 3, 0xFF );
	ifsFile.close();

	if( !stricmp( (const char*)szLine, "BIN" ) )
		isBinary = true;
	else
		isBinary = false;

	return isBinary;
}

const char * cAccounts::GetFilePath( void )
{
	if( !PathToFile.empty() )
		return PathToFile.c_str();
	return NULL;
}

void cAccounts::SetFilePath( const char *filepath )
{
	if( !FileExists( filepath ) )
		return;
	isBinary = isValid = false;
	PathToFile.erase();
	PathToFile = filepath;
	isBinary=FileType();
	if( isReloaded )
//		LoadAccounts( isBinary?1:0 );	// check isBinary
		LoadAccounts();
}

bool cAccounts::UnloadAccounts( void )
{
	typedef map< string, ACTREC *>::const_iterator CI;
	for( CI p = actMap.begin(); p != actMap.end(); ++p )
	{	// This should remove the memory defined with them
		delete p->second;
		actMap.erase( p->first );
	}
	return true;
}

long cAccounts::GetAccountCount( void )
{
	return AccountCount;
}

ACTREC *cAccounts::GetAccount( const char *username )
{
	string s1( username );
	map< string, ACTREC *>::iterator p = actMap.find( s1 );
	if( p != actMap.end() )
	{	//	Account was found
		return p->second;
	}
	else
	{	//	Account was not found
		return NULL;
	}
}

long cAccounts::SaveAccounts( int mode )
{	// Mode: (0) - Text (1) - StraightBinary (2)-XORed Binary (Not supported yet)
#pragma note( "This function will overwrite the file and write out all accounts" )
	// NOTE: This function will overwrite the file and write out ALL accounts.
	return SaveAccounts( "accounts.adm", mode );
}

long cAccounts::SaveAccounts( const char *filename, int mode )
{	// filename is never used
	ofstream outStream;
	ACTREC *temp = NULL;
	char chb[512];
	map<int,ACTREC*>::iterator iter;

	switch( mode )
	{
	case 1:	// Binary
		if( !PathToFile.empty() )	// If this is empty then use new system to save, meaning that an account is saves with its characters, and character items stored as well
		{	
			return SaveAccounts( 0 );
		}
		for( iter = acctByNum.begin(); iter != acctByNum.end(); iter++ ) //for( temp = FirstAccount(); !FinishedAccounts(); temp = NextAccount() )
		{
			temp = iter->second;
			sprintf( chb, "%s/%s.sav", temp->path, temp->username );
			ofstream actstream;
			actstream.open(chb, ios::out|ios::binary);
			if(!actstream.is_open())
			{
				ErrNum = 0x00000100;	// [00]-Unknown [00]-Memory [00]-i/o [00]-syntax =0x[00][00][00][00]
				ErrDesc = "Unable to open the specified file";
				return -1;
			}
			//	Write out the type, and version information of this filesave
			actstream << "BIN" << 0x00 << 0xFF;	//	Specify that this is a binary file
			actstream << "AV" << SVER << "-UV" << VER << "-BD" << BUILD << "-DS" << time(NULL) << "-ED" << REALBUILD << 0x00 << 0xFF;	// Output version line for detection later
			//	Write out account information at the top of the file as a header
			actstream << temp->id;
			actstream << temp->username;
			actstream << temp->password;
			actstream << temp->path;
			actstream << temp->status;
			actstream << temp->comment;
			actstream << temp->ban_date;
			actstream << temp->ban_duration;
			actstream << temp->charactercount;
			actstream << temp->ipaddress;
			actstream << temp->isbanned;
			actstream << temp->ispublic;
			actstream << temp->isxgm << 0x00 << 0xFF;
			//	Write out the first characters header file
			for( UI08 i = 0; i < 5; i++ )
			{
				if( temp->characters[i] != NULL )
					actstream << temp->characters[i]->GetSerial();
				else
					actstream << INVALIDSERIAL;
			}
		}
		break;
	case 0:
	default:
		FILE *acctfile = fopen( filename, "w" );
		if( acctfile )
		{
			fprintf( acctfile, "//AV%s-UV%s-BD%s-DS%li-ED%s\n", SVER, VER, BUILD, time( NULL ), REALBUILD );
			fprintf( acctfile, "//------------------------------------------------------------------------------\n");
			fprintf( acctfile, "//Accounts.adm[TEXT] : UOX3 uses this file for accounts storage for shard access\n");
			fprintf( acctfile, "//------------------------------------------------------------------------------\n");

			for( iter = acctByNum.begin(); iter != acctByNum.end(); iter++ )//for( temp = FirstAccount(); !FinishedAccounts(); temp = NextAccount() )
			{
				temp = iter->second;
				fprintf( acctfile, "SECTION ACCOUNT %li\n", temp->id );
				fprintf( acctfile, "{\n" );
				fprintf( acctfile, "NAME %s\n", temp->username );
				fprintf( acctfile, "PASS %s\n", temp->password );
				if( temp->isbanned ) 
					fprintf( acctfile, "BAN %i\n", temp->isbanned?1:0 );
				if( temp->ban_duration != -1 ) 
					fprintf( acctfile, "TIMEBAN %i\n", temp->ban_duration );
				if( temp->ipaddress[0] != 0 )
					fprintf( acctfile, "LASTIP %i.%i.%i.%i\n", (UI08)(temp->ipaddress[0])>>24, (UI08)(temp->ipaddress[0])>>16, (UI08)(temp->ipaddress[0])>>8, (UI08)(temp->ipaddress[0])%256 );
				else 
					fprintf( acctfile, "LASTIP %i.%i.%i.%i\n", (UI08)(temp->ipaddress[1])>>24, (UI08)(temp->ipaddress[1])>>16, (UI08)(temp->ipaddress[1])>>8, (UI08)(temp->ipaddress[1])%256 );
				fprintf( acctfile, "PUBLIC %s\n", temp->ispublic?"ON":"OFF" );				
				fprintf( acctfile, "CONTACT %s\n", temp->comment );
				fprintf( acctfile, "XGMCLIENT %s\n", temp->isxgm?"ON":"OFF" );
				for( UI08 i = 0; i < 5; i++ )
					fprintf( acctfile, "CHARACTER-%i %i\n", i + 1, (temp->characters[i] != NULL)?(temp->characters[i]->GetSerial()):(INVALIDSERIAL) );
				fprintf( acctfile, "}\n" );
			}
			fprintf( acctfile, "\n\nEOF\n\n" );
			fclose( acctfile );
			acctfile = NULL;
		}
		else
		{
			Console.Error( 1, "Failed to open the account file %s for writing", filename );
			Console.Error( 1, "Character information will not be saved" );
		}
		break;

	}//switch mode
	return 0;
}


ACTREC *cAccounts::GetAccountByID( SI32 id )
{
	if( id == -1 )
		return NULL;
	map< int, ACTREC * >::iterator iter = acctByNum.find( id );
	if( iter != acctByNum.end() )
		return iter->second;
	else
		return NULL;
}

ACTREC * cAccounts::FirstAccount( void )
{
	gCI = actMap.begin();
	if( FinishedAccounts() )
		return NULL;
	return gCI->second;
}

ACTREC * cAccounts::NextAccount( void )
{
	if( FinishedAccounts() )
		return NULL;
	gCI++;
	if( FinishedAccounts() )
		return NULL;
	return gCI->second;
}

bool cAccounts::FinishedAccounts( void )
{
	return ( gCI == actMap.end() );
}

bool cAccounts::AddCharacterToAccount( SI32 accountid, CChar *object)
{
	bool exitvalue = false;
	ACTREC *holding = GetAccountByID( accountid );
	if( holding == NULL || object == NULL ) 
	{
		ErrDesc = "Unable to add character to account.";
		ErrNum = 0xFFFFFFFF;
		return exitvalue;
	}
	for( UI08 i = 0; i <= 4; i++ ) 
	{
		if( holding->characters[i] == NULL )
		{	// Ok this is an empty slot we can use this one
			holding->characters[i] = object;
			holding->charactercount++;
			return true;
		}
	}
	return exitvalue;
}

void cAccounts::AddAccount( string username, string password, string contact )
{
	ACTREC *toAdd = new ACTREC;
	memset( toAdd, 0x00, sizeof( ACTREC ) );
	toAdd->inworld = INVALIDSERIAL;
	toAdd->characters.resize( 5 );
	toAdd->id = highestAccountNumber++;

	strcpy( toAdd->username, username.c_str() );
	strcpy( toAdd->password, password.c_str() );
	strcpy( toAdd->comment, contact.c_str() );

	actMap[username] = toAdd;
	acctByNum[toAdd->id] = toAdd;
}
void cAccounts::DeleteAccount( string username )
{
	iIterator p;
	map<int, ACTREC *>::iterator i;
	p = actMap.find( username.c_str() );
	if( p != actMap.end() )
	{
		i = acctByNum.find( p->second->id );
		if( i != acctByNum.end() )
			acctByNum.erase( i );
		delete p->second;
		actMap.erase( p );
	}
}

bool cAccounts::IPExists( UI08 ip1, UI08 ip2, UI08 ip3, UI08 ip4 ) const
{
	ACTREC *temp = NULL;
	UI32 targIP = calcserial( ip1, ip2, ip3, ip4 );
	typedef map< string, ACTREC *>::const_iterator CI;
	for( CI p = actMap.begin(); p != actMap.end(); ++p )
	{
		temp = p->second;
		if( temp->ipaddress[0] == targIP || temp->ipaddress[1] == targIP )
			return true;
	}
	return false;
}

bool cAccounts::RemoveCharacterFromAccount( SI32 accountid, UI08 slot )
{
	ACTREC *temp = NULL;
	temp = GetAccountByID( accountid );
	return RemoveCharacterFromAccount( temp, slot );
}
bool cAccounts::RemoveCharacterFromAccount( ACTREC *toRemove, UI08 slot )
{
	if( slot >= toRemove->characters.size() )
		return false;
	toRemove->charactercount--;
	for( UI08 j = slot; j < toRemove->characters.size()-1; j++ )
		toRemove->characters[j] = toRemove->characters[j+1];
	toRemove->characters[4] = NULL;
	return true;
}

SI32 cAccounts::Count( void ) const
{
	return actMap.size();
}

void cAccounts::PostLoadProcessing( void )
{
	ACTREC *pAcct = NULL;
	for( iIterator b = actMap.begin(); b != actMap.end(); b++ )
	{
		pAcct = b->second;
		if( pAcct != NULL )
		{
			if( pAcct->id == -1 )
				pAcct->id = highestAccountNumber++;
			acctByNum[pAcct->id] = pAcct;
		}
	}
}
