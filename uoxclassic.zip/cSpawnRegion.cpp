#include "uox3.h"
#include "ssection.h"

cSpawnRegion::cSpawnRegion( SI32 spawnregion ) : nexttime( 0 ), call( 1 ), x1( 0 ), x2( 0 ), y1( 0 ), y2( 0 ),
maxcspawn( 0 ), maxispawn( 0 ), maxtime( 0 ), mintime( 0 ), regionnum( spawnregion ), curcspawn( 0 ), curispawn( 0 ),
worldNumber( 0 )
{
	items.resize( 0 );
	npcs.resize( 0 );
	strncpy( name, Dictionary->GetEntry( 1117 ), 128 );
// note: doesn't go here, but i'll see it here.  when an item is spawned, as soon as it's moved it needs to lose it's
// spawn setting.  If not, then when people pick up spawned items, they will disappear (on region spawns)
}

cSpawnRegion::~cSpawnRegion()
{
	items.resize( 0 );
	npcs.resize( 0 );
// Wipe out all items and npcs
}

//o---------------------------------------------------------------------------o
//|	Function	-	const char *GetName( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs region name
//o---------------------------------------------------------------------------o
const char *cSpawnRegion::GetName( void ) const
{
	return name;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetName( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets region name (max 128 characters)
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetName( const char *newName )
{
	strncpy( name, newName, 128 );
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetMaxSpawn( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs maximum amount of objects a region can spawn
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetMaxSpawn( void ) const
{
	return ( maxcspawn + maxispawn );
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetMaxCharSpawn( void )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Return maximum amount of characters to spawn
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetMaxCharSpawn( void ) const
{
	return maxcspawn;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetMaxItemSpawn( void )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Return maximum amount of items to spawn
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetMaxItemSpawn( void ) const
{
	return maxispawn;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetMaxCharSpawn( SI32 newVal )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets maximum amount of characters a region can spawn
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetMaxCharSpawn( SI32 newVal )
{
	maxcspawn = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetMaxItemSpawn( SI32 newVal )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets maximum amount of items a region can spawn
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetMaxItemSpawn( SI32 newVal )
{
	maxispawn = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetCurrent( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs current amount of objects spawned
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetCurrent( void ) const
{
	return ( curcspawn + curispawn );
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetCurrentCharAmt( void )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs current amount of characters spawned
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetCurrentCharAmt( void ) const
{
	return curcspawn;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetCurrentItemAmt( void )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs current amount of items spawned
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetCurrentItemAmt( void ) const
{
	return curispawn;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetRegionNum( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs region number
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetRegionNum( void ) const
{
	return regionnum;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetRegionNum( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets region number
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetRegionNum( SI32 newVal )
{
	regionnum = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetMinTime( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs the minimum amount of time to pass before a spawnregion
//|					spawns a new object
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetMinTime( void ) const
{
	return mintime;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetMinTime( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets the minimum amount of time to pass before a spawnregion
//|					spawns a new object
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetMinTime( SI32 newVal )
{
	mintime = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetMaxTime( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs the maximum amount of time to pass before a spawnregion
//|					spawns a new object
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetMaxTime( void ) const
{
	return maxtime;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetMaxTime( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets the maximum amount of time to pass before a spawnregion
//|					spawns a new object
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetMaxTime( SI32 newVal )
{
	maxtime = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetNextTime( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grab when a spawnregion will next spawn a new object
//o---------------------------------------------------------------------------o
SI32 cSpawnRegion::GetNextTime( void ) const
{
	return nexttime;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetNextTime( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Set when a spawnregion will next spawn a new object
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetNextTime( SI32 newVal )
{
	nexttime = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetY1( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs y1 to get the y pos of the top corner of the spawnregion
//o---------------------------------------------------------------------------o
SI16 cSpawnRegion::GetY1( void ) const
{
	return y1;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetY1( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets y1 to the y pos of the top corner of the spawnregion
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetY1( SI16 newVal )
{
	y1 = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetX1( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs x1 to get the x pos of the top corner of the spawnregion
//o---------------------------------------------------------------------------o
SI16 cSpawnRegion::GetX1( void ) const
{
	return x1;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetX1( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets x1 to the x pos of the top corner of the spawnregion
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetX1( SI16 newVal )
{
	x1 = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetY2( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs y2 to get the y pos of the bottom corner of the spawnregion
//o---------------------------------------------------------------------------o
SI16 cSpawnRegion::GetY2( void ) const
{
	return y2;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetY2( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets y2 to the y pos of the bottom corner of the spawnregion
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetY2( SI16 newVal )
{
	y2 = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SI32 GetX2( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Grabs x2 to get the x pos of the bottom corner of the spawnregion
//o---------------------------------------------------------------------------o
SI16 cSpawnRegion::GetX2( void ) const
{
	return x2;
}

//o---------------------------------------------------------------------------o
//|	Function	-	SetX2( void )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Sets x2 to the x pos of the second corner of the spawnregion
//o---------------------------------------------------------------------------o
void cSpawnRegion::SetX2( SI16 newVal )
{
	x2 = newVal;
}

//o---------------------------------------------------------------------------o
//|	Function	-	Load( ScriptSection *toScan )
//|	Programmer	-	Zane
//o---------------------------------------------------------------------------o
//|	Purpose		-	Loads the spawnregion from spawn.scp script entry
//o---------------------------------------------------------------------------o
void cSpawnRegion::Load( ScriptSection *toScan )
{
	const char *data2 = NULL;
	char sect[512];
	char data[512];

	for( const char *tag = toScan->First(); !toScan->AtEnd(); tag = toScan->Next() )
	{
		if( tag == NULL )
			continue;

		data2 = toScan->GrabData();
		strcpy( data, data2 );
		strupr( data );

		if( !strcmp( tag, "NPCLIST" ) )
		{
			sprintf( sect, "NPCLIST %s", data );
			ScriptSection *CharList = FileLookup->FindEntry( sect, npc_def );
			if( CharList != NULL )
			{
				for( const char *itm = CharList->First() ; !CharList->AtEnd(); itm = CharList->Next() )
					npcs.push_back( itm );
			}
		}
		else if( !strcmp( tag, "NPC" ) )
			npcs.push_back( data );
		else if( !strcmp( tag, "ITEMLIST" ) )
		{
			sprintf( sect, "ITEMLIST %s", data );
			ScriptSection *ItemList = FileLookup->FindEntry( sect, items_def );
			if( ItemList != NULL )
			{
				for( const char *itm = ItemList->First() ; !ItemList->AtEnd(); itm = ItemList->Next() )
					items.push_back( itm );
			}
		}
		else if( !strcmp( tag, "ITEM" ) )
			items.push_back( data );
		else if( !strcmp( tag, "MAXITEMS" ) )
			maxispawn = makeNum( data );
		else if( !strcmp( tag, "MAXNPCS" ) )
			maxcspawn = makeNum( data );
		else if( !strcmp( tag, "X1" ) )
			x1 = (SI16)makeNum( data );
		else if( !strcmp( tag, "X2" ) )
			x2 = (SI16)makeNum( data );
		else if( !strcmp( tag, "Y1" ) )
			y1 = (SI16)makeNum( data );
		else if( !strcmp( tag, "Y2" ) )
			y2 = (SI16)makeNum( data );
		else if( !strcmp( tag, "MINTIME" ) )
			mintime = makeNum( data );
		else if( !strcmp( tag, "MAXTIME" ) )
			maxtime = makeNum( data );
		else if( !strcmp( tag, "NAME" ) )
			strncpy( name, data, 128 );
		else if( !strcmp( tag, "CALL" ) )
			call = (SI16)makeNum( data );
		else if( !strcmp( tag, "WORLD" ) )
			worldNumber = (UI08)makeNum( data );
	}
}

//o---------------------------------------------------------------------------o
//|	Function	-	doRegionSpawn( void )
//|	Programmer	-	Unknown
//o---------------------------------------------------------------------------o
//|	Purpose		-	Do spawn stuff for spawnregion
//o---------------------------------------------------------------------------o
void cSpawnRegion::doRegionSpawn( void )
{
	SI32 j = 0;
	SI32 k = 0;

	if( npcs.size() == 0 )
		maxcspawn = 0;
	if( items.size() == 0 )
		maxispawn = 0;

	while( scharlist.size() < maxcspawn )
		scharlist.push_back(NULL);
	while( sitemlist.size() < maxispawn )
		sitemlist.push_back(NULL);

	for( SI32 i = 0 ; i < call ; i++ )
	{
		for( ; j < scharlist.size() ; j++ )
		{
			if( scharlist[j] != NULL )
				continue;
			else
			{
				scharlist[j] = RegionSpawnChar();
				if( scharlist[j] != NULL )
					scharlist[j]->ShouldSave( false );
				break;
			}
		}

// sitemlist.size() should be 
		for( ; k < sitemlist.size() ; k++ )
		{
			if( sitemlist[k] != NULL && !sitemlist[k]->ShouldSave())
				continue;
			else
			{
				sitemlist[k] = RegionSpawnItem();
				if( sitemlist[k] != NULL )
				{
					SI16 x = 0, y = 0;
					SI08 z = 0;
					if( FindSpotForItem( x, y, z ) )
					{
						sitemlist[k]->SetLocation( x, y, z ); // On a move, we should set save to true
						sitemlist[k]->SetSpawn( 0, 1, regionnum, 0, calcItemFromSer( sitemlist[k]->GetSerial() ) );
						RefreshItem( sitemlist[k] );
						sitemlist[k]->ShouldSave( false );
					} 
					else 
						Items->DeleItem( sitemlist[k] );
				}
				break;
			}
		}
	}
}

//o---------------------------------------------------------------------------o
//|	Function	-	cChar *RegionSpawnChar( void )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Do a char spawn
//o---------------------------------------------------------------------------o
CChar *cSpawnRegion::RegionSpawnChar( void )
{
	return Npcs->SpawnNPC( this, npcs[RandomNum( 0, npcs.size() - 1 )], worldNumber );
}

//o---------------------------------------------------------------------------o
//|	Function	-	cItem *RegionSpawnItem( void )
//|	Programmer	-	Thyme
//o---------------------------------------------------------------------------o
//|	Purpose		-	Do a item spawn
//o---------------------------------------------------------------------------o
CItem *cSpawnRegion::RegionSpawnItem( void )
{
	return Items->CreateScriptItem( NULL, items[RandomNum( 0, items.size() - 1) ], false, worldNumber );
}

//o---------------------------------------------------------------------------o
//|	Function	-	bool FindSpotForItem( SI16 &x, SI16 &y, SI08 &z )
//|	Programmer	-	Unknown
//o---------------------------------------------------------------------------o
//|	Purpose		-	Find a random spot within a region valid for dropping an item
//o---------------------------------------------------------------------------o
bool cSpawnRegion::FindSpotForItem( SI16 &x, SI16 &y, SI08 &z )
{
	for( UI08 a = 0; a < 100; a++ ) 
	{
		x = (SI16)(RandomNum( x1, x2 ));
		y = (SI16)(RandomNum( y1, y2 ));
		z = Map->MapElevation( x, y, worldNumber );
		
		if( Map->CanMonsterMoveHere( x, y, z, worldNumber ) )
			return true;
	}
	Console << "Problem regionspawn [" << regionnum << "] found. Nothing will be spawned" << myendl;
	return false;
}