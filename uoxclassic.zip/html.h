#ifndef __html_h_
#define __html_h_

// HTML Stuff

void	DumpPlayerHTML( CChar *mChar );

//		On ServerShutdown this Function
//		should walk the vector of Templates
//		and look for OfflinePage flagged
//		definitions which it tries to parse
//		then.
void	CheckOfflinePages( void );

//		Is now used to read in all
//		HTML Definitions and build
//		a list of status pages
//		in memory
void	InitHTMLDirs( void );

//		Checks for outdated HTML Pages
//		and tries to parse the corr. 
//		Template
void	CheckHTMLPages( void );

#endif
