// cAccount.h: interface for the cAccount class.
//
//////////////////////////////////////////////////////////////////////
//#include "uox3.h"
#include <map>
#include <string>

#if !defined(AFX_CACCOUNT_H__6FD26C86_F155_11D3_9002_00104B73C455__INCLUDED_)
#define AFX_CACCOUNT_H__6FD26C86_F155_11D3_9002_00104B73C455__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

using namespace std;

typedef map< string, ACTREC *>::const_iterator cIterator;
typedef map< string, ACTREC *>::iterator iIterator;

enum ActFlags 
{
	ALLOWED		= 0x00000000,
	BANNED		= 0x00000001,
	TIMELIMIT	= 0x00000002,
	LOGACTIONS	= 0x00000003
};

class cAccounts  
{
public:
	virtual long	LoadAccounts( int mode );
	bool			AddCharacterToAccount( SI32 accountid, CChar *object );
	bool			RemoveCharacterFromAccount( SI32 accountid, UI08 slot );
	bool			RemoveCharacterFromAccount( ACTREC *toRemove, UI08 slot );
	ACTREC *		NextAccount( void );
	bool			FinishedAccounts( void );
	ACTREC *		FirstAccount( void );
	virtual ACTREC *GetAccount( const char *username );
	virtual ACTREC *GetAccountByID( SI32 id );
	long			GetAccountCount( void );
	virtual bool	UnloadAccounts( void );
	void			SetFilePath( const char *filepath );
	const char *	GetFilePath( void );

	bool			isBinary;
	bool			isValid;
	char *			szAccountsVersion;
	string			ErrDesc;
	UI32			ErrNum;

	const char *	CheckAccountsVersion( const char *filename );
	bool			ConvertAccounts( const char *filename );
	virtual long	LoadAccounts( void );
					cAccounts();
					cAccounts( const char *accountsfile );
	virtual			~cAccounts();

	bool			isReloaded;

	void			AddAccount( string username, string password, string contact );
	void			DeleteAccount( string username );
	bool			IPExists( UI08 ip1, UI08 ip2, UI08 ip3, UI08 ip4 ) const;

	SI32			Count( void ) const;
	virtual long	SaveAccounts( const char *filename, int mode );
	virtual long	SaveAccounts( int mode );
private:
	cIterator		gCI;
	long			AccountCount;
	bool			FileType();
	virtual UI32	ReadToken( FILE *openfile );
	map< string, ACTREC * > actMap;
	map< int, ACTREC * > acctByNum;
	string			PathToFile;
	SI32			highestAccountNumber;
	void			PostLoadProcessing( void );
protected:
};

#endif // !defined(AFX_CACCOUNT_H__6FD26C86_F155_11D3_9002_00104B73C455__INCLUDED_)
