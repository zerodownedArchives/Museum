#ifndef __CSCRIPT_H__
#define __CSCRIPT_H__

enum ScriptEvent
{
	seOnCreate = 0,			//	*	Done for PCs on global script
	seOnDelete,				//	**
	seOnSpeech,				//	*	Missing item response at the moment
	seInRange,				//	*	Missing character in range
	seOnCollide,			//	**	Items only
	seOnSteal,				//	**
	seOnDispel,				//	**
	seOnSkill,
	seOnStat,
	seOnAttack,
	seOnDefense,
	seOnSkillGain,			//	**
	seOnSkillLoss,			//	**
	seOnSkillChange,		//	**
	seOnStatGain,			//	**
	seOnStatLoss,			//	**
	seOnStatChange,			//	**
	seOnDrop,
	seOnPickup,
	seOnSwing,
	seOnDecay,
	seOnTransfer,
	seOnLeaving,			//	**
	seOnEntrance,			//	**
	seOnEquip,				//	**
	seOnUnequip,			//	**
	seOnUse,				//	**
	seOutOfRange,			//	*	Missing character out of range
	seOnLogin,				//	**
	seOnFall,
	seOnSell,
	seOnBuy,
	seOnAISliver,			//	**
	seOnSystemSlice,
	seOnUnknownTrigger,
	seOnLightChange,
	seOnXYZEvent,
	seOnPortal,
	seOnTimer,				//	**
	seOnDeath,				//	**
	seOnResurrect,			//	**
	seOnFlagChange,			//	**
	seOnHungerChange,		//	**
	seOnStolenFrom,			//	**
	seOnSnooped,			//	**
	seOnEnterRegion,		//  **
	seOnLeaveRegion,		//	**
	seOnSpellTarget,
	seOnSpellCast,
	seOnSpellSuccess,
	seOnTalk,
	seOnScrollCast,
	seOnSpeechInput,
	seOnSpellGain,
	seOnSpellLoss,
	seOnSkillCheck
};

struct SEGump
{
	stringList *one, *two;
	UI32 TextID;
};

struct InUseEntry
{
	bool		inUse;
	JSObject *	toUse;
	InUseEntry() : inUse( false ), toUse( NULL ) { }
	InUseEntry( bool iU, JSObject *tU ) : inUse( iU ), toUse( tU ) { }
};

enum IUEEntries
{
	IUE_RACE = 0,
	IUE_CHAR,
	IUE_ITEM,
	IUE_SOCK,
	IUE_GUILD,
	IUE_REGION,
	IUE_UNKNOWN,
	IUE_COUNT
};

class cScript
{
private:
	JSScript *	targScript;
	JSContext *	targContext;
	JSObject *	targObject;

	JSObject	*ItemProto;
	JSObject	*GumpProto;
	JSObject	*CharProto;
	JSObject	*SpellProto;
	JSObject	*SpellsProto;
	JSObject	*GuildProto;
	JSObject	*GuildsProto;
	JSObject	*RaceProto;
	JSObject	*RacesProto;
	JSObject	*SocketProto;
	JSObject	*SocketsProto;
	JSObject	*RegionProto;
	JSObject	*RegionsProto;

	bool		isFiring;
	UI32		eventPresence[2];
	bool		EventExists( ScriptEvent eventNum ) const;
	void		SetEventExists( ScriptEvent eventNum, bool status );

	vector< InUseEntry >	raceObjects;
	vector< InUseEntry >	charObjects;
	vector< InUseEntry >	itemObjects;
	vector< InUseEntry >	sockObjects;
	vector< InUseEntry >	guildObjects;
	vector< InUseEntry >	regionObjects;

	vector< SEGump * >		gumpDisplays;

	UI32		FindFreePosition( IUEEntries iType ) const;
	UI32		FindUsedObject( IUEEntries iType, JSObject *toFind ) const;
	JSObject *	MakeNewObject( IUEEntries iType );
	void		RemoveFromRoot( void );

public:

	void		ReleaseObject( JSObject *toRelease, IUEEntries iType );
	JSObject *	AcquireObject( IUEEntries iType );

	SI32		NewGumpList( void );
	SEGump *	GetGumpList( SI32 index );
	void		RemoveGumpList( SI32 index );
	void		SendGumpList( SI32 index, UOXSOCKET toSendTo );

	void		HandleGumpPress( cSocket *pressing, long button );
	void		HandleGumpInput( cSocket *pressing );

				cScript( string targFile );
	virtual		~cScript();

	JSObject *	Object( void ) const;	// returns object pointer

	bool		OnCreate( cBaseObject *thingCreated );
	bool		OnDelete( cBaseObject *thingDestroyed );
	bool		OnSpeech( const char *speech, CChar *personTalking, CChar *talkingTo );
	bool		InRange( CChar *person, CChar *targPlayer );
	bool		InRange( CChar *person, CItem *targItem   );
	bool		OnCollide( UOXSOCKET targSock, CChar *objColliding, CItem *objCollideWith );
	bool		OnSteal( CChar *thief, CItem *theft );
	bool		OnDispel( cBaseObject *dispelled );
	bool		OnSkill( cBaseObject *skillUse, SI08 skillUsed );
	bool		OnStat( void );
	bool		OnAttack( CChar *attacker, CChar *defender );
	bool		OnDefense( CChar *attacker, CChar *defender );
	bool		OnSkillGain( CChar *player, SI08 skill );
	bool		OnSkillLoss( CChar *player, SI08 skill );
	bool		OnSkillChange( CChar *player, SI08 skill );
	bool		OnStatGain( CChar *player, UI32 stat );
	bool		OnStatLoss( CChar *player, UI32 stat );
	bool		OnStatChange( CChar *player, UI32 stat );
	bool		OnDrop( CItem *item, CChar *dropper );
	bool		OnPickup( CItem *item, CChar *pickerUpper );
	bool		OnSwing( CItem *swinging, CChar *swinger, CChar *swingTarg );
	bool		OnDecay( CItem *decaying );
	bool		OnTransfer( CItem *transferred, CChar *source, CChar *target );
	bool		OnLeaving( CMultiObj *left, cBaseObject *leaving );
	bool		OnEntrance( CMultiObj *left, cBaseObject *leaving );
	bool		OnEquip( CChar *equipper, CItem *equipping );
	bool		OnUnequip( CChar *equipper, CItem *equipping );
	bool		OnUse( CChar *user, CItem *iUsing );
	bool		OutOfRange( CChar *person, cBaseObject *objVanish );
	bool		OnLogin( cSocket *sockPlayer, CChar *pPlayer );
	bool		OnFall( CChar *pFall, SI08 fallDistance );
	bool		OnSell( void );
	bool		OnBuy( void );
	bool		OnAISliver( CChar *pSliver );
	bool		OnSystemSlice( void );
	bool		OnUnknownTrigger( void );
	bool		OnLightChange( void );
	bool		OnXYZEvent( void );
	bool		OnPortal( void );
	bool		OnTimer( cBaseObject *tObject, UI08 timerID );
	bool		OnDeath( CChar *pDead );
	bool		OnResurrect( CChar *pAlive );
	bool		OnFlagChange( CChar *pChanging, UI08 newStatus, UI08 oldStatus );
	bool		OnHungerChange( CChar *pChanging, SI08 newStatus );
	bool		OnStolenFrom( CChar *stealing, CChar *stolenFrom, CItem *stolen );
	bool		OnSnooped( CChar *snooped, CChar *snooper, bool success );
	bool		OnEnterRegion( CChar *entering, SI16 region );
	bool		OnLeaveRegion( CChar *entering, SI16 region );
	bool		OnSpellTarget( CChar *target, CChar *caster, UI08 spellNum );
	bool		OnSpellTarget( CItem *target, CChar *caster, UI08 spellNum );
	bool		DoCallback( cSocket *tSock, SERIAL targeted, UI08 callNum );
	SI16		OnSpellCast( CChar *tChar, UI08 SpellID );
	SI16		OnScrollCast( CChar *tChar, UI08 SpellID );
	bool		OnSpellSuccess( CChar *tChar, UI08 SpellID );
	bool		OnTalk( CChar *myChar, const char *mySpeech );
	bool		OnSpeechInput( CChar *myChar, CItem *myItem, const char *mySpeech );
	bool		OnSpellGain( CItem *book, const UI08 spellNum );
	bool		OnSpellLoss( CItem *book, const UI08 spellNum );
	bool		OnSkillCheck( CChar *myChar, const UI08 skill, const UI16 lowSkill, const UI16 highSkill );

	bool		CallParticularEvent( char *eventToCall, jsval *params, SI32 numParams );

	//	Critical handler type stuff
	bool		IsFiring( void );
	void		Firing( void );
	void		Stop( void );
};


#endif

