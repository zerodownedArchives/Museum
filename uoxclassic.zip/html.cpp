#include "uox3.h"
#include "cSkillClass.h"
#include <string>
#include "html.h"
#include "ssection.h"

//:Terrin: I was out to fix sprintf(s, "%s%c", s, c ) but here they were
//         mostly cases of someone not knowing out to do a backslash
//         in a constant string.
struct sHTMLInformation 
{
	string	Identifier;
	UI32	UpdateTimer;
	char 	InputFile[MAX_PATH];
	bool	Loaded;
	bool	OfflinePage;
	string	Content;
	char 	OutputFile[MAX_PATH];
	UI32	ScheduledUpdate; 
};

void guildpage( int, char * );
void guildhtml( void );
void ParseHTMLTemplate ( sHTMLInformation *Information );
void DumpTownPageHTML( UI08 townNum );
void DumpTownHTML( void );

vector< sHTMLInformation > HTMLIdentifiers;

char guildDir[256];
char playerDir[256];
char imgDir[256];
char townDir[256];

char guildHTMLDir[256];
char playerHTMLDir[256];
char imgHTMLDir[256];
char townHTMLDir[256];

//	
//	reads in all HTML definitions and threats them as own "files"...
//	

void InitHTMLDirs( void )
{
	HTMLIdentifiers.clear();

	ScpList *toWalk = FileLookup->GetFiles( html_def );
	if( toWalk == NULL )
		return;

	for( UI32 i = 0; i < toWalk->size(); i++ )
	{
		if( (*toWalk)[i] != NULL )
		{
			Script *toCheck = (*toWalk)[i];
			if( toWalk == NULL )
				continue;
			
			UI32 NumEntries = toCheck->NumEntries();
			if( NumEntries == 0 )
				continue; 

//			for( UI32 i = 0; i < NumEntries; i++ )
			for( ScriptSection *found = toCheck->FirstEntry(); found != NULL; found = toCheck->NextEntry() )
			{
				string SectionName = toCheck->EntryName();
				struct sHTMLInformation Information;
				Information.OfflinePage = false;
				
				const char *tag = NULL;
				const char *data = NULL;

				for( tag = found->First(); !found->AtEnd(); tag = found->Next() )
				{
					data = found->GrabData();
					
					if( !strcmp( tag, "UPDATE" ) ) 
					{ 
						// Debug only...
						// Console << "Found " << tag << " with data: " << data << "\n";
						Information.UpdateTimer = makeNum( data );
					}
					else if( !strcmp( tag, "OFFLINE" ) )
					{
						Information.OfflinePage = true;
					}
					else if( !strcmp( tag, "INPUT" ) )
					{
						sprintf( Information.InputFile, "%s", data );
					}
					else if( !strcmp( tag, "OUTPUT" ) )
					{
						sprintf( Information.OutputFile, "%s", data );
					}
				}

				Information.ScheduledUpdate = 0;
				Information.Identifier = SectionName;
				Information.Loaded = false;

				HTMLIdentifiers.push_back( Information );
			}
		}
	}
}

#pragma note( "Needs to be updated, dont know what WriteBulkHTML does!" )
void WriteBulkHTML( void )
{
	//guildhtml();
	//DumpTownHTML();
}

void CheckOfflinePages( void )
{
	if( HTMLIdentifiers.size() < 1 )
		return;

	for( UI32 i = 0; i < HTMLIdentifiers.size(); i++ )
	{
		if( HTMLIdentifiers[i].OfflinePage ) 
		{
			ParseHTMLTemplate( &HTMLIdentifiers[i] );
		}
	}
}

void CheckHTMLPages( void )
{
	// Walk the existing HTML Informations and check whether they should be updated or not...
	if( HTMLIdentifiers.size() < 1 )
	{
		return;
	}

	for( UI32 i = 0; i < HTMLIdentifiers.size(); i++ )
	{
		if( ( !HTMLIdentifiers[i].OfflinePage ) && ( HTMLIdentifiers[i].ScheduledUpdate < uiCurrentTime ) )
		{
			HTMLIdentifiers[i].ScheduledUpdate = BuildTimeValue( (R32)HTMLIdentifiers[i].UpdateTimer );
			ParseHTMLTemplate( &HTMLIdentifiers[i] );
		}
	}
}

//	
//	Reads the HTML Template
//	Handles the processing
//	Output it to the path set in *Information
//	
void ParseHTMLTemplate( sHTMLInformation *Information )
{
	// Only read the Status Page if it's not already loaded
	if( !Information->Loaded )
	{
		Information->Content = "";

		ifstream InputFile( Information->InputFile );

		if( !InputFile.is_open() )
		{
			Console.Error( 1, "Couldn't open HTML Template File %s", Information->InputFile );
			return;
		}
		
		while( !InputFile.eof() )
		{
			string Line;
			getline( InputFile, Line );
			Information->Content += Line;
		}

		InputFile.close();

		Information->Loaded = true;
	}

	// Parse the Content...
	string ParsedContent = Information->Content;

	//***************************************/
	// Replacing Placeholders
	//***************************************/

	int Pos;

	// Account-Count
	char AccountCount[32];
	sprintf( AccountCount, "%d", Accounts->GetAccountCount() );
	for( Pos = ParsedContent.find("%accounts"); Pos >= 0; Pos = ParsedContent.find( "%accounts" ) )
	{
		ParsedContent.replace( Pos, 9, AccountCount );
	}

	// Version
	string Version = VER;
	#ifdef __NT__
		Version += " [WIN32]";
	#else
		Version += " [LINUX]";
	#endif

	for( Pos = ParsedContent.find( "%version" ); Pos >= 0; Pos = ParsedContent.find( "%version" ) )
	{
		ParsedContent.replace( Pos, 8, Version );
	}

	// Character Count
	char CharacterCount[32];
	sprintf( CharacterCount, "%d", chars.Count() );
	for( Pos = ParsedContent.find( "%charcount" ); Pos >= 0; Pos = ParsedContent.find( "%charcount" ) )
	{
		ParsedContent.replace( Pos, 10, CharacterCount );
	}

	// Item Count
	char ItemCount[32];
	sprintf( ItemCount, "%d", items.Count() );
	for( Pos = ParsedContent.find("%itemcount"); Pos >= 0; Pos = ParsedContent.find( "%itemcount" ) )
	{
		ParsedContent.replace( Pos, 10, ItemCount );
	}

	// Connection Count (GMs, Counselors, Player)
	UI32 gm = 0, cns = 0, ccount = 0;
	
	// Get all Network Connections
	Network->PushConn();
	cSocket *tSock = NULL;
	for( tSock = Network->FirstSocket(); !Network->FinishedSockets(); tSock = Network->NextSocket() )
	{
		CChar *tChar = tSock->CurrcharObj();
		if( tChar == NULL )
				continue;
	
		if( tChar->IsGM() )
			gm++;
		else if( tChar->IsCounselor() )
			cns++;
		else 
			ccount++;
	}
	Network->PopConn();

	// GMs
	char GMCount[32];
	sprintf( GMCount, "%d", gm );
	for( Pos = ParsedContent.find( "%online_gms" ); Pos >= 0; Pos = ParsedContent.find( "%online_gms" ) )
	{
		ParsedContent.replace( Pos, 11, GMCount );
	}

	// Counselor
	char CounsiCount[32];
	sprintf( CounsiCount, "%d", cns );
	for( Pos = ParsedContent.find( "%online_couns" ); Pos >= 0; Pos = ParsedContent.find( "%online_couns" ) )
	{
		ParsedContent.replace( Pos, 13, CounsiCount );
	}

	// Player
	char PlayerCount[32];
	sprintf( PlayerCount, "%d", ccount );
	for( Pos = ParsedContent.find( "%online_player" ); Pos >= 0; Pos = ParsedContent.find( "%online_player" ) )
	{
		ParsedContent.replace( Pos, 14, PlayerCount );
	}

	// Total
	char AllCount[32];
	sprintf( AllCount, "%d", (ccount + gm + cns) );
	for( Pos = ParsedContent.find( "%online_all" ); Pos >= 0; Pos = ParsedContent.find( "%online_all" ) )
	{
		ParsedContent.replace( Pos, 11, AllCount );
	}

	//RealTime( time_str )
	char time_str[80];
	RealTime( time_str );
	for( Pos = ParsedContent.find( "%time" ); Pos >= 0; Pos = ParsedContent.find( "%time" ) )
	{
		ParsedContent.replace( Pos, 5, time_str );
	}

	// IP(s) + PORT(s)
	UI16 ServerCount = (UI16)cwmWorldState->ServerData()->GetServerCount();
	if( ServerCount > 0 ) 
	{
		for( UI16 i = 0; i < ServerCount; i++ )
		{
			physicalServer *mServ = cwmWorldState->ServerData()->GetServerEntry( i );
			char ipToken[8]; // i think we'll never get higher than 2 digits, anyway...
			sprintf( ipToken, "%%ip%i", i+1 );

			if( mServ != NULL )	
			{
				for( Pos = ParsedContent.find( ipToken ); Pos >= 0; Pos = ParsedContent.find( ipToken ) )
				{
					ParsedContent.replace( Pos, strlen(ipToken), mServ->ip.c_str() );
				}
			}
			
			char portToken[10]; // i think we'll never get higher than 2 digits, anyway...
			sprintf( portToken, "%%port%i", i+1 );

			if( mServ != NULL )	
			{
				for( Pos = ParsedContent.find( portToken ); Pos >= 0; Pos = ParsedContent.find( portToken ) )
				{
					char myPort[5];
					sprintf( myPort, "%i", mServ->port );
					ParsedContent.replace( Pos, strlen( portToken ), myPort );
				}
			}
			char serverToken[10]; // i think we'll never get higher than 2 digits, anyway...
			sprintf( serverToken, "%%server%i", i+1 );

			if( mServ != NULL )	
			{
				for( Pos = ParsedContent.find( serverToken ); Pos >= 0; Pos = ParsedContent.find( serverToken ) )
				{
					ParsedContent.replace( Pos, strlen( serverToken ), mServ->name.c_str() );
				}
			}
		}
	}
	// PLAYERLIST
	for( Pos = ParsedContent.find( "%playerlist%" ); Pos >= 0; Pos = ParsedContent.find( "%playerlist%" ) )
	{
		UI32 SecondPos = ParsedContent.find( "%playerlist%", Pos+1 );
		string myInline = ParsedContent.substr( Pos, SecondPos - Pos + 12 );
		string PlayerList;

		Network->PushConn();
		for( tSock = Network->FirstSocket(); !Network->FinishedSockets(); tSock = Network->NextSocket() )
		{ 
			if( tSock != NULL )
			{
				CChar *tChar = tSock->CurrcharObj();
				if( tChar != NULL )
				{
					string parsedInline = myInline;
					parsedInline.replace( 0, 12, "" );
					parsedInline.replace( parsedInline.length()-12, 12, "" );

//					Tokens for the PlayerList
//					%playername
//					%playertitle
//					%playerip
//					%playeraccount
//					%playerx
//					%playery
//					%playerz
//					%playerrace

					// PlayerName
					SI32 sPos;
					for( sPos = parsedInline.find( "%playername" ); sPos >= 0; sPos = parsedInline.find( "%playername" ) )
					{
						parsedInline.replace( sPos, 11, tChar->GetName() );
					}

					// PlayerTitle
					for( sPos = parsedInline.find( "%playertitle" ); sPos >= 0; sPos = parsedInline.find( "%playertitle" ) )
					{
						parsedInline.replace( sPos, 12, tChar->GetTitle() );
					}

					// PlayerIP
					for( sPos = parsedInline.find( "%playerip" ); sPos >= 0; sPos = parsedInline.find( "%playerip" ) )
					{
						cSocket *mySock = calcSocketObjFromChar( tChar );
						char ClientIP[32];
						sprintf( ClientIP, "%i.%i.%i.%i", mySock->ClientIP4(), mySock->ClientIP3(), mySock->ClientIP3(), mySock->ClientIP1() );
						parsedInline.replace( sPos, 9, ClientIP );
					}

					// PlayerAccount
					for( sPos = parsedInline.find( "%playeraccount" ); sPos >= 0; sPos = parsedInline.find( "%playeraccount" ) )
					{
						ACTREC *toScan = tChar->GetAccountObj();
						if( toScan != NULL )
							parsedInline.replace( sPos, 14, toScan->username );
					}

					// PlayerX
					for( sPos = parsedInline.find( "%playerx" ); sPos >= 0; sPos = parsedInline.find( "%playerx" ) )
					{
						char myX[5];
						sprintf( myX, "%i", tChar->GetX() );
						parsedInline.replace( sPos, 8, myX );
					}

					// PlayerY
					for( sPos = parsedInline.find( "%playery" ); sPos >= 0; sPos = parsedInline.find( "%playery" ) )
					{
						char myY[5];
						sprintf( myY, "%i", tChar->GetY() );
						parsedInline.replace( sPos, 8, myY );
					}

					// PlayerZ
					for( sPos = parsedInline.find( "%playerz" ); sPos >= 0; sPos = parsedInline.find( "%playerz" ) )
					{
						char myZ[3];
						sprintf( myZ, "%i", tChar->GetZ() );
						parsedInline.replace( sPos, 8, myZ );
					}

					// PlayerRace -- needs testing
					for( sPos = parsedInline.find( "%playerrace" ); sPos >= 0; sPos = parsedInline.find( "%playerrace" ) )
					{
						RACEID myRace = tChar->GetRace();
						const char *rName = Races->Name( myRace );
						UI32 raceLenName = strlen( rName );
						char *myRaceName = new char[ raceLenName + 1 ];
						strcpy( myRaceName, rName );

						if( myRaceName != NULL ) 
							parsedInline.replace( sPos, 11, myRaceName );
						delete [] myRaceName;
					}

					PlayerList += parsedInline;
				}
			}
		}
		Network->PopConn();	

		ParsedContent.replace( Pos, myInline.length(), PlayerList );
	}

	// GuildCount
	char GuildCount[32];
	sprintf( GuildCount, "%d", GuildSys->NumGuilds() );
	for( Pos = ParsedContent.find( "%guildcount" ); Pos >= 0; Pos = ParsedContent.find( "%guildcount" ) )
	{
		ParsedContent.replace( Pos, 11, PlayerCount );
	}

	// GUILDLIST
	for( Pos = ParsedContent.find( "%guildlist%" ); Pos >= 0; Pos = ParsedContent.find( "%guildlist%" ) )
	{
		UI32 SecondPos = ParsedContent.find( "%guildlist%", Pos+1 );
		string myInline = ParsedContent.substr( Pos, SecondPos - Pos + 11 );
		string GuildList;

	
		for( SI16 i = 0; i < (SI16)GuildSys->NumGuilds(); i++ ) 
		{
			string parsedInline = myInline;
			parsedInline.replace( 0, 11, "" );
			parsedInline.replace( parsedInline.length()-11, 11, "" );

			parsedInline += "Yeah it worked";

//			Tokens for the GuildList
//			%guildid
//			%guildname

			// GuildID
			SI32 sPos;
			CGuild *myGuild = GuildSys->Guild( i );

			char GuildID[6];
			sprintf( GuildID, "%d", i );
			for( sPos = parsedInline.find( "%guildid" ); sPos >= 0; sPos = parsedInline.find( "%guildid" ) )
			{
				parsedInline.replace( sPos, 8, GuildID );
			}

			// GuildName
			for( sPos = parsedInline.find( "%guildname" ); sPos >= 0; sPos = parsedInline.find( "%guildname" ) )
			{
				parsedInline.replace( sPos, 10, myGuild->Name() );
			}

			GuildList += parsedInline;
		}

		ParsedContent.replace( Pos, myInline.length(), GuildList );
	}

	//NPCCount
	char npcs[6];
	UI32 npccount = 0;

	if( npccount == 0 )
	{
		for( UI32 a = 0; a < chars.Count(); a++ )
		{
			if( chars[a].isFree() )
				continue;
			if( chars[a].IsNpc() )
				npccount++;
		}
	}

	sprintf(npcs, "%i", npccount);

	for( Pos = ParsedContent.find( "%npcs" ); Pos >= 0; Pos = ParsedContent.find( "%npcs" ) )
	{
		ParsedContent.replace( Pos, 5, npcs );
	}

	// Performance Dump
	R64 eps = 0.00000000001;
	for( Pos = ParsedContent.find( "%performance" ); Pos >= 0; Pos = ParsedContent.find( "%performance" ) )
	{
		string performance;
		ostringstream myStream( performance );

		myStream << "Network code: " << (R32)((R32)networkTime/(R32)networkTimeCount) << "msec [" << networkTimeCount << " samples] <BR>";
		myStream << "Timer code: " << (R32)((R32)timerTime/(R32)timerTimeCount) << "msec [" << timerTimeCount << " samples] <BR>";
		myStream << "Auto code: " << (R32)((R32)autoTime/(R32)autoTimeCount) << "msec [" << autoTimeCount << " samples] <BR>";
		myStream << "Loop Time: " << (R32)((R32)loopTime/(R32)loopTimeCount) << "msec [" << loopTimeCount << " samples] <BR>";
		if( !( loopTime < eps ||  loopTimeCount < eps ) )
			myStream << "Simulation Cycles: " << (1000.0*(1.0/(R32)((R32)loopTime/(R32)loopTimeCount))) << " per sec <BR>";
		else 
			myStream << "Simulation Cycles: Greater than 10000 <BR> ";
		

		ParsedContent.replace(Pos, 12, myStream.str());
	}

	// Uptime
	for( Pos = ParsedContent.find( "%uptime" ); Pos >= 0; Pos = ParsedContent.find( "%uptime" ) )
	{
		string uptime;
		
		char sh[3], sm[3], ss[3];
		ostringstream myStream( uptime );

		UI32 total, hr, min, sec;

		total = (uiCurrentTime - starttime ) / CLOCKS_PER_SEC;
		hr = total / 3600;
		if( hr < 10 && hr <= 60 ) 
			sprintf( sh,"0%i",hr );
		else 
			sprintf( sh, "%i", hr);
		total -= hr * 3600;
		min = total / 60;
		if( min < 10 && min <= 60 ) 
			sprintf( sm, "0%i", min );
		else 
			sprintf( sm, "%i", min );
		total -= min*60;
		sec = total;
		if( sec < 10 && sec <= 60 ) 
			sprintf( ss, "0%i", sec );
		else 
			sprintf( ss, "%i", sec );
		myStream << sh << ":" << sm << ":" << ss;		

		ParsedContent.replace(Pos, 7, myStream.str());
	}

	// Simulation Cycles (whatever that may be...)
	for( Pos = ParsedContent.find( "%simcycles" ); Pos >= 0; Pos = ParsedContent.find( "%simcycles" ) )
	{
		string simcycles;
		ostringstream myStream( simcycles );

		if( !( loopTime < eps ||  loopTimeCount < eps ) )
			myStream << "Simulation Cycles: " << (1000.0*(1.0/(R32)((R32)loopTime/(R32)loopTimeCount))) << " per sec <BR>";
		else 
			myStream << "Simulation Cycles: Greater than 10000 <BR> ";
		

		ParsedContent.replace(Pos, 10, myStream.str());
	}

	// Update Time in SECONDS
	for( Pos = ParsedContent.find( "%updatetime" ); Pos >= 0; Pos = ParsedContent.find( "%updatetime" ) )
	{
		char UpdateTimer[32]; // Could be a high value...
		sprintf( UpdateTimer, "%i", Information->UpdateTimer );

		ParsedContent.replace( Pos, 11, UpdateTimer );
	}

	//***************************************/
	// End Replacing Placeholders
	//***************************************/	

	// Print the Content out to the new file...
	ofstream 	Output( Information->OutputFile );
	if( !Output.is_open() ) 
	{
		Console.Error( 1, "Couldn't open the template file %s for writing", Information->OutputFile );
		return;
	}

	Output << ParsedContent;

	Output.close();
}

void guildhtml( void )
{
	/*char time_str[80], hfile[512], temp[512];
	int i, nxtg=1;

	ScriptSection *targData = FileLookup->FindEntry( "GUILD_MAIN", html_def );
	if( targData == NULL )
		return;
	char *tag = NULL, *data = NULL;
	tag = targData->First(); data = targData->GrabData();
	sprintf( hfile, "%s/%s %s", guildDir, tag, data );
	ofstream html( hfile );
	if( !html.is_open() ) 
		return;
	for( ; !targData->AtEnd(); tag = targData->Next() )
	{
		data = targData->GrabData();
		switch( tag[0] )
		{
		case 'L':
			if( !strcmp( tag, "LINE" ) )
				html << data << endl;
			break;
		case 'T':
			if( !strcmp( tag, "TIME" ) )
				html << RealTime( time_str ) << endl;
			break;
		case 'G':
			if( !strcmp( tag, "GUILDLIST" ) )
			{
				for( i = 0; i < GuildSys->NumGuilds(); i++ )
				{
					CGuild *mGuild = GuildSys->Guild( i );
					if( mGuild != NULL && strlen( mGuild->Name() ) > 1 )
					{
						sprintf( temp, "<A HREF=\"%s/%i.html\">%s [%s]</A>&nbsp;&nbsp;\n", guildHTMLDir, i, mGuild->Name(), mGuild->Abbreviation() );
						html << temp;
						if( mGuild->Type() != GT_STANDARD )
							html << mGuild->TypeName();
						html << "<br>" << endl;
						guildpage( i, guildDir );
					}
				}
			}
			break;
		case 'N':
			if( !strcmp( tag, "NEXTGUILD" ) )
			{
				CGuild *nGuild = GuildSys->Guild( nxtg );
				if( nGuild != NULL && strlen( nGuild->Name() ) > 1 )
				{
					i = nxtg;
					sprintf( temp, "<A HREF=\"%s/%i.html\">%s [%s]</A>&nbsp;&nbsp;\n", guildHTMLDir, i, nGuild->Name(), nGuild->Abbreviation() );
					html << temp;
					if( nGuild->Type() != GT_STANDARD )
						html << nGuild->TypeName();
					html << "<br>" << endl;
					guildpage( i, guildDir );
				}
				nxtg++;
			}
			break;
		}
	}
	html.close();*/
}

#pragma note( "guildpage needs an update too" )
void guildpage( int i, char *gdir )
{
	/*char time_str[80],gfile[512];//sh[3],sm[3],ss[3];

	CGuild *mGuild = GuildSys->Guild( i );
	if( mGuild == NULL )
		return;

	ScriptSection *targData = NULL;
	char *tag = NULL, *data = NULL;
	targData = FileLookup->FindEntry( "GUILD_PAGE", html_def );
	if( targData == NULL )
		return;
	sprintf( gfile, "%s/%i.html", guildDir, i );
	ofstream ghtml( gfile );
	if( !ghtml.is_open() )
		return;
	for( tag = targData->First(); !targData->AtEnd(); tag = targData->Next() )
	{
		data = targData->GrabData();
		switch( tag[0] )
		{
		case 'A':
			if( !strcmp( tag, "ABREV" ) )
				ghtml << mGuild->Abbreviation();
			else if( !strcmp( tag, "ALLYLIST" ) )
			{
				GuildID ga;
				for( ga = mGuild->FirstAlly(); !mGuild->FinishedAlly(); ga = mGuild->NextAlly() )
				{
					if( ga != -1 )
					{
						CGuild *cga = GuildSys->Guild( ga );
						if( cga != NULL )
						{
							ghtml << "<A HREF=\"" << guildHTMLDir << "/" << ga << ".html\">" << cga->Name() << "&nbsp;[" << cga->Abbreviation() << "]</A>&nbsp;&nbsp;" << endl;
							if( cga->Type() != GT_STANDARD )
								ghtml << "[" << cga->TypeName() << "]";
							ghtml << "<br>" << endl;
						}
					}
				}
			}
			break;
		case 'C':
			if( !strcmp( tag, "CHARTER" ) )
				ghtml << mGuild->Charter();
			break;
		case 'L':
			if( !strcmp( tag, "LINE" ) )
				ghtml << data << endl;
			else if( !strcmp( tag, "LOGO" ) )
				ghtml << guildHTMLDir << "/" << i << ".jpg";
			break;
		case 'M':
			if( !strcmp( tag, "MEMBERCOUNT" ) )
				ghtml << mGuild->NumMembers();
			else if( !strcmp( tag, "MASTER" ) )
			{
				CChar *gMaster = calcCharObjFromSer( mGuild->Master() );
				if( gMaster != NULL )
					ghtml << "<A HREF=\"" << playerHTMLDir << "/" << gMaster->GetSerial() << ".html\">" << gMaster->GetName() << "</a>";
			}
			else if( !strcmp( tag, "MEMBERLIST" ) )
			{
				CChar *ml;
				for( SERIAL mlSer = mGuild->FirstMember(); !mGuild->FinishedMember(); mlSer = mGuild->NextMember() )
				{
					ml = calcCharObjFromSer( mlSer );
					if( ml != NULL )
						ghtml << "<A HREF=\"" << playerHTMLDir << "/" << ml->GetSerial() << ".html\">" << ml->GetName() << "</a> [" << ml->GetGuildTitle() << "]<BR>" << endl;
				}
			}
			break;
		case 'N':
			if( !strcmp( tag, "NAME" ) )
				ghtml << mGuild->Name();
			else if( !strcmp( tag, "NEXTALLY" ) )
			{
				GuildID nga = mGuild->NextAlly();
				if( nga != -1 )
				{
					CGuild *cnga = GuildSys->Guild( nga );
					ghtml << "<A HREF=\"" << guildHTMLDir << "/" << nga << ".html\">" << cnga->Name() << "&nbsp;[" << cnga->Abbreviation() << "]</A>&nbsp;&nbsp;" << endl;
					if( cnga->Type() != GT_STANDARD )
						ghtml << "[" << cnga->TypeName() << "]";
				}
			}
			else if( !strcmp( tag, "NEXTWAR" ) )
			{
				GuildID ngw = mGuild->NextWar();
				if( ngw != -1 )
				{
					CGuild *cngw = GuildSys->Guild( ngw );
					ghtml << "<A HREF=\"" << guildHTMLDir << "/" << ngw << ".html\">" << cngw->Name() << "&nbsp;[" << cngw->Abbreviation() << "]</A>&nbsp;&nbsp;" << endl;
					if( cngw->Type() != GT_STANDARD )
						ghtml << "[" << cngw->TypeName() << "]";
				}
			}
			else if( !strcmp( tag, "NEXTMEMBER" ) )
			{
				CChar *nxMember = calcCharObjFromSer( mGuild->NextMember() );
				if( nxMember != NULL )
						ghtml << "<A HREF=\"" << playerHTMLDir << "/" << nxMember->GetSerial() << ".html\">" << nxMember->GetName() << "</a> [" << nxMember->GetGuildTitle() << "]<BR>" << endl;
			}
			else if( !strcmp( tag, "NEXTRECRUIT" ) )
			{
				CChar *nxRecruit = calcCharObjFromSer( mGuild->NextRecruit() );
				if( nxRecruit != NULL )
						ghtml << "<A HREF=\"" << playerHTMLDir << "/" << nxRecruit->GetSerial() << ".html\">" << nxRecruit->GetName() << "</a> [" << nxRecruit->GetGuildTitle() << "]<BR>" << endl;
			}
			break;
		case 'R':
			if( !strcmp( tag, "RECRUITCOUNT" ) )
				ghtml << mGuild->NumRecruits();
			else if( !strcmp( tag, "RECRUITLIST" ) )
			{
				CChar *rl;
				for( SERIAL rlSer = mGuild->FirstRecruit(); !mGuild->FinishedRecruits(); rlSer = mGuild->NextRecruit() )
				{
					rl = calcCharObjFromSer( rlSer );
					if( rl != NULL )
						ghtml << "<A HREF=\"" << playerHTMLDir << "/" << rl->GetSerial() << ".html\">" << rl->GetName() << "</a> [" << rl->GetGuildTitle() << "]<BR>" << endl;
				}
			}
			break;
		case 'S':
			if( !strcmp( tag, "SITE" ) )
				ghtml << mGuild->Webpage();
			break;
		case 'T':
			if( !strcmp( tag, "TYPE" ) )
			{
				if( mGuild->Type() != GT_STANDARD )
					ghtml << mGuild->TypeName();
			}
			else if( !strcmp( tag, "TIME" ) )
				ghtml << RealTime( time_str );
			break;
		case 'W':
			if( !strcmp( tag, "WARLIST" ) )
			{
				GuildID gw;
				for( gw = mGuild->FirstWar(); !mGuild->FinishedWar(); gw = mGuild->NextWar() )
				{
					if( gw != -1 )
					{
						CGuild *cgw = GuildSys->Guild( gw );
						if( cgw != NULL )
						{
							ghtml << "<A HREF=\"" << guildHTMLDir << "/" << gw << ".html\">" << cgw->Name() << "&nbsp;[" << cgw->Abbreviation() << "]</A>&nbsp;&nbsp;" << endl;
							if( cgw->Type() != GT_STANDARD )
								ghtml << "[" << cgw->TypeName() << "]";
							ghtml << "<br>" << endl;
						}
					}
				}
			}
			break;
		}
	}
	ghtml.close();*/
}

#pragma note( "Update candidate no. 1" )
void DumpPlayerHTML( CChar* mChar )
{
/*	if( i == NULL )
		return;
	char time_str[80],gfile[512];
	int a, counter;

	ScriptSection *targData = NULL;
	char *tag, *data;
	targData = FileLookup->FindEntry( "PLAYER_PAGE", html_def );
	if( targData == NULL )
		return;
	sprintf( gfile, "%s/%i.html", playerDir, i->GetSerial() );
	ofstream ghtml( gfile );
	if( !ghtml.is_open() )
		return;
	for( tag = targData->First(); !targData->AtEnd(); tag = targData->Next() )
	{
		data = targData->GrabData();
		switch( tag[0] )
		{
		case 'D':
			if( !strcmp( tag, "DEX" ) ) 
				ghtml << i->GetDexterity();
			break;
		case 'F':
			if( !strcmp( tag, "FAME" ) )
				ghtml << i->GetFame();
			break;
		case 'I':
			if( !strcmp( tag, "INT" ) )
				ghtml << i->GetIntelligence();
			break;
		case 'K':
			if( !strcmp( tag, "KILLS" ) ) 
				ghtml << i->GetKills();
			else if( !strcmp( tag, "KARMA" ) )
				ghtml << i->GetKarma();
			break;
		case 'L':
			if( !strcmp( tag, "LINE" ) ) 
				ghtml << data << endl;
			break;
		case 'N':
			if( !strcmp( tag, "NAME" ) ) 
				ghtml << i->GetName();
			else if( !strcmp( tag, "NOTOTITLE" ) )
				ghtml << title3( i );
			break;
		case 'P':
			if( !strcmp( tag, "PROWESSTITLE" ) )
				ghtml << title1( i );
			break;
		case 'R':
			if( !strcmp( tag, "RACE" ) ) 
				ghtml << Races->Name( i->GetRace() );
			break;
		case 'S':
			if( !strcmp( tag, "STR" ) ) 
				ghtml << i->GetStrength();
			else if( !strcmp( tag, "SKILLTITLE" ) )
				ghtml << title2( i );
			break;
		case 'T':
			if( !strcmp( tag, "TITLE" ) )
				ghtml << i->GetTitle();
			else if( !strcmp( tag, "TIME" ) ) 
				ghtml << RealTime( time_str );
			else if( !strcmp( tag, "TOPSKILLS" ) )
			{
				ghtml << "<table width=\"600\">" << endl;
				vector< cSkillClass > nSkills;
				for( counter = 0 ; counter < TRUESKILLS ; counter++ )
					nSkills.push_back( cSkillClass( counter, i->GetBaseSkill( counter ) ) );
				sort( nSkills.rbegin(), nSkills.rend() );

				a = makeNum( data );
				for( counter = 0; counter < a; counter++ )
					ghtml << "<tr><td><img src=\"" << imgHTMLDir << "/" << skillname[nSkills[counter].skill] << ".gif\"><td>" << skillname[nSkills[counter].skill] << "<td>" << ((R32)(nSkills[counter].value)) / 10.0 << endl;

				ghtml << "</table>" << endl;
			}
			break;
		}
	} 
	ghtml.close();*/
}

#pragma note( "needs to be updated" )
void DumpTownHTML( void )
{
	/*char time_str[80];
	int i;

	ScriptSection *targData = FileLookup->FindEntry( "TOWN_MAIN", html_def );
	if( targData == NULL )
		return;
	char *tag = NULL, *data = NULL;
	char gfile[256];
	sprintf( gfile, "%s/main.html", townDir );
	ofstream html( gfile );
	if( !html.is_open() ) 
		return;
	for( tag = targData->First(); !targData->AtEnd(); tag = targData->Next() )
	{
		data = targData->GrabData();
		switch( tag[0] )
		{
		case 'L':
			if( !strcmp( tag, "LINE" ) )
				html << data << endl;
			break;
		case 'T':
			if( !strcmp( tag, "TIME" ) )
				html << RealTime( time_str ) << endl;
			else if( !strcmp( tag, "TOWNLIST" ) )
			{
				html << "<table>";
				for( i = 0; i < 256; i++ )
				{
					if( region[i] != NULL && strcmp( region[i]->GetName(), "the Wilderness" ) )
					{
						html << "<tr><td><A HREF=\"" << townHTMLDir << "/" << i << ".html\">" << region[i]->GetName() << "</A><br>" << endl;
						DumpTownPageHTML( i );
					}
				}
				html << "</table>";
			}
			break;
		}
	}
	html.close();*/
}

#pragma note( "Needs to be updated to reflect the new template system" )
void DumpTownPageHTML( UI08 townNum )
{
	/*ScriptSection *townData = FileLookup->FindEntry( "TOWN_PAGE", html_def );
	if( townData == NULL )
		return;
	char tName[512];
	sprintf( tName, "%s/%i.html", townDir, townNum );
	ofstream html( tName );
	if( !html.is_open() )
		return;

	map< bool, string > activeMap;
	activeMap[true] = "true";
	activeMap[false] = "false";

	CWeather *mWeather = Weather->Weather( region[townNum]->GetWeather() );

	char *tag = NULL, *data = NULL;
	for( tag = townData->First(); !townData->AtEnd(); tag = townData->Next() )
	{
		data = townData->GrabData();
		switch( tag[0] )
		{
		case 'A':
			if( !strcmp( tag, "APPEARANCE" ) )
				html << WorldTypeNames[region[townNum]->GetAppearance()].c_str();
			break;
		case 'C':
			if( !strcmp( tag, "CURTEMP" ) && mWeather != NULL )
				html << mWeather->Temp();
			else if( !strcmp( tag, "CURLIGHT" ) && mWeather != NULL )
				html << mWeather->CurrentLight();
			else if( !strcmp( tag, "CURWIND" ) && mWeather != NULL )
				html << mWeather->WindSpeed();
			break;
		case 'E':
			if( !strcmp( tag, "ENUMORE" ) )
			{
				html << "<table>";
				for( int i = 0; i < region[townNum]->GetNumOrePreferences(); i++ )
				{
					const orePref *toGet = region[townNum]->GetOrePreference( i );
					miningData *mdGet = Skills->GetOre( i );
					if( toGet != NULL && mdGet != NULL )
					{
						html << "<tr><td>" << mdGet->name.c_str();
						html << "<td>" << (R32)toGet->percentChance;
					}
				}
				html << "</table>";
			}
			else if( !strcmp( tag, "ENUMENEMYTOWNS" ) )
			{
				html << "<table><tr><th>Name<th>Population<th>Race</tr>";
				RACEID ourRace = region[townNum]->GetRace();
				for( int i = 0; i < 256; i++ )
				{
					if( region[i] != NULL && i != townNum )
					{
						if( Races->CompareByRace( ourRace, region[i]->GetRace() ) < 0 )
						{
							html << "<tr><td>";
							if( region[i]->IsDungeon() )
								html << "Dungeon ";
							html << region[i]->GetName() << "<td>" << region[i]->GetPopulation() << "<td>" << Races->Name( region[i]->GetRace() ) << "</tr>" << endl;
						}
					}
				}
				html << "</table>";
			}
			break;
		case 'I':
			if( !strcmp( tag, "IFGUARDED" ) )
				html << activeMap[region[townNum]->IsGuarded()].c_str();
			else if( !strcmp( tag, "IFGATE" ) )
				html << activeMap[region[townNum]->CanGate()].c_str();
			else if( !strcmp( tag, "IFRECALL" ) )
				html << activeMap[region[townNum]->CanRecall()].c_str();
			else if( !strcmp( tag, "IFMARK" ) )
				html << activeMap[region[townNum]->CanMark()].c_str();
			else if( !strcmp( tag, "IFAGGRESSIVE" ) )
				html << activeMap[region[townNum]->CanCastAggressive()].c_str();
			break;
		case 'M':
			if( !strcmp( tag, "MAYOR" ) )
			{
				CHARACTER mayor = region[townNum]->GetMayor();
				if( mayor != INVALIDSERIAL )
					html << chars[mayor].GetName();
			}
			else if( !strcmp( tag, "MAXTEMP" ) && mWeather != NULL )
				html << mWeather->MaxTemp();
			else if( !strcmp( tag, "MAXLIGHT" ) && mWeather != NULL )
				html << mWeather->LightMax();
			else if( !strcmp( tag, "MAXWIND" ) && mWeather != NULL )
				html << mWeather->MaxWindSpeed();
			else if( !strcmp( tag, "MINTEMP" ) && mWeather != NULL )
				html << mWeather->MinTemp();
			else if( !strcmp( tag, "MINLIGHT" ) && mWeather != NULL )
				html << mWeather->LightMin();
			else if( !strcmp( tag, "MINWIND" ) && mWeather != NULL )
				html << mWeather->MinWindSpeed();
			break;
		case 'N':
			if( !strcmp( tag, "NUMGUARDS" ) )
				html << region[townNum]->NumGuards();
			else if( !strcmp( tag, "NUMMEMBERS" ) )
				html << region[townNum]->GetPopulation();
			else if( !strcmp( tag, "NAME" ) )
			{
				if( region[townNum]->IsDungeon() )
					html << "Dungeon " << region[townNum]->GetName();
				else
					html << region[townNum]->GetName();
			}
			else if( !strcmp( tag, "NUMORE" ) )
				html << region[townNum]->GetNumOrePreferences();
			break;
		case 'O':
			if( !strcmp( tag, "OWNER" ) )
				html << region[townNum]->GetOwner();
		case 'R':
			if( !strcmp( tag, "RACE" ) )
				html << Races->Name( region[townNum]->GetRace() );
			break;
		}
	}
	html.close();*/
}

