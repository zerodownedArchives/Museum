#ifndef __UOXLINUX_H__
#define __UOXLINUX_H__

#include <string>
#include <unistd.h> // for chdir and getcwd
#include <sys/stat.h> // for mkdir
#include <errno.h> // for errno
using namespace std;

//	  This header is kind of a patch for all the windows-specific things in
//	 uox3. --Sean

inline int stricmp( const char *s1, const char *s2 )
{
	return strcasecmp( s1, s2 );
}

inline int strnicmp( const char *s1, const char *s2, size_t n )
{
	return strncasecmp( s1, s2, n );
}

inline void GetCurrentDirectory( size_t size, char *buf )
{
	getcwd( buf, size );
}

inline int _chdir( const char *newDirectory )
{
	return chdir( newDirectory );
}

inline int _mkdir( const char *dirname )
{
	return mkdir( dirname, 0755 );
}

#endif
