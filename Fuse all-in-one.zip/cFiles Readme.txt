4-27-99
cFiles ver 21 rev 2

new worldfile with signs and functional moongate station

updated dungdata.txt

note: doors have been moved from world.dor to wspawn.txt