
#define DBLIBDEF __declspec(dllexport)
#define DBLIBFNDEF extern "C" DBLIBDEF

DBLIBFNDEF DWORD db_FindString(char *pDatabase, char *pProperty, char *pOperation, char *pCompareto);
DBLIBFNDEF DWORD db_GetValue(char *pDatabase, DWORD dwIndex, char *pProperty);
DBLIBFNDEF void db_GetString(char *pDatabase, DWORD dwIndex, char *pProperty, char *pValue);
