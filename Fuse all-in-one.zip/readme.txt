To make FuseEasyCommand work you must make a macro (in UO) for
the key (V-alt-shift-ctrl) and set it to PASTE, then ezcmd will
pass msgs to the client, call it an undocumented feature! ;)

------------------------------------------------------------------

Command text for Fuse EasyCommand re-written for Cfuse 3-99

send bugs or typos to : stein_unf@hotmail.com